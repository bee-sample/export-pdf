package com.tle.exportingpdf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExportingPdfApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExportingPdfApplication.class, args);
	}

}
